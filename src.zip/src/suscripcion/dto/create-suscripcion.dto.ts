export class CreateSuscripcionDto {}

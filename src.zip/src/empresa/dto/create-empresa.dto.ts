export class CreateEmpresaDto {}

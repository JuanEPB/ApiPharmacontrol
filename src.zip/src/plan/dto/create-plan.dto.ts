export class CreatePlanDto {}
